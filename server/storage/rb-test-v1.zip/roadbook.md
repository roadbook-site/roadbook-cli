---
id: rb-test-v1
name: Test Roadbook
version: 1.0.0
description: A simple test roadbook.
---

## Step 1
GOTO "https://example.com"
